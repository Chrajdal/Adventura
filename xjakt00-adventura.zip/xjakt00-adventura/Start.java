/*******************************************************************************
 * Třidá spouští hru.
 *
 * @author    Tomáš Jakubčin (xjakt00)
 * @version   pro školní rok 2010/2011
 */
public class Start
{

/**
 * Konstruktor.
 */
private Start() {
}

/**
 * Metoda main.
 */

public static void main (String [ ] args){
TextoveRozhrani tr = new TextoveRozhrani (); 
tr.hraj ();
}
}